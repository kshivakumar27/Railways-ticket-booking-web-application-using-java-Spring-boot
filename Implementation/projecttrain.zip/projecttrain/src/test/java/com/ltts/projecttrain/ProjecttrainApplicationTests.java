package com.ltts.projecttrain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjecttrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
