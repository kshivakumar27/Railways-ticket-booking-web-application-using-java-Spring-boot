package com.ltts.projecttrain.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltts.projecttrain.bo.Trainbo;
import com.ltts.projecttrain.model.Train;

@Service
public class TrainService {

	 @Autowired
	Trainbo tb;
	
	public Train insertuser(Train t) {
		return tb.save(t);
		
	}
	
	
}
