package com.ltts.projecttrain.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Ticket {

	
	@Id
	private int ticketid;
	private String trainnames;
	private LocalTime showtime;
	private LocalDate bookingdate;
	private LocalDate showdate;
	private String tickettype;
	private String status;
	private int nooftickets;
	public int getTicketid() {
		return ticketid;
	}
	public Ticket(int ticketid, String trainnames, LocalTime showtime, LocalDate bookingdate, LocalDate showdate,
			String tickettype, String status, int nooftickets) {
		super();
		this.ticketid = ticketid;
		this.trainnames = trainnames;
		this.showtime = showtime;
		this.bookingdate = bookingdate;
		this.showdate = showdate;
		this.tickettype = tickettype;
		this.status = status;
		this.nooftickets = nooftickets;
	}
	public Ticket() {
		super();
	}
	public String getTrainnames() {
		return trainnames;
	}
	public void setTrainnames(String trainnames) {
		this.trainnames = trainnames;
	}
	public LocalTime getShowtime() {
		return showtime;
	}
	public void setShowtime(LocalTime showtime) {
		this.showtime = showtime;
	}
	public LocalDate getBookingdate() {
		return bookingdate;
	}
	public void setBookingdate(LocalDate bookingdate) {
		this.bookingdate = bookingdate;
	}
	public LocalDate getShowdate() {
		return showdate;
	}
	public void setShowdate(LocalDate showdate) {
		this.showdate = showdate;
	}
	public String getTickettype() {
		return tickettype;
	}
	public void setTickettype(String tickettype) {
		this.tickettype = tickettype;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getNooftickets() {
		return nooftickets;
	}
	public void setNooftickets(int nooftickets) {
		this.nooftickets = nooftickets;
	}
	public void setTicketid(int ticketid) {
		this.ticketid = ticketid;
	}
	@Override
	public String toString() {
		return "Ticket [ticketid=" + ticketid + ", trainnames=" + trainnames + ", showtime=" + showtime + ", bookingdate="
				+ bookingdate + ", showdate=" + showdate + ", tickettype=" + tickettype + ", status=" + status
				+ ", nooftickets=" + nooftickets + "]";
	}
	
	
}
