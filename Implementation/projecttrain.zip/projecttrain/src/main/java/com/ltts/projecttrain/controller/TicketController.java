package com.ltts.projecttrain.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.ltts.projecttrain.bo.Trainbo;
import com.ltts.projecttrain.model.Train;


@RestController
public class TicketController {
	/*
	@Autowired
	Trainbo tb;
    @RequestMapping("/bookticket")
    public ModelAndView m1(Model model) {
    	ModelAndView mv=new ModelAndView("bookticket");
    	List<Train> li=tb.findAll();
    	model.addAttribute("list",li);
    	System.out.println("Executed");
    	
    	return mv;
    
    */
    }
    
    
    
	
	

