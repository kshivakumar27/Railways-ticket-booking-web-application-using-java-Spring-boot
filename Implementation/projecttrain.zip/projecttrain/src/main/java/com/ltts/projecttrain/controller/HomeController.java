package com.ltts.projecttrain.controller;

import java.time.LocalDate;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.beans.factory.annotation.Autowired(required=true);
import com.ltts.projecttrain.bo.Trainbo;
import com.ltts.projecttrain.bo.UserBo;
import com.ltts.projecttrain.bo.UserBo1;
//import com.ltts.projecttrain.bo.TrainBo;
import com.ltts.projecttrain.model.Train;
import com.ltts.projecttrain.model.User;

//import antlr.collections.List;


@Component
@RestController
//@RequestMapping("/index")
public class HomeController {
	
	
	
	@Autowired
	Trainbo td;
	
	
//	@Autowired
//	UserBo ub;
	
	
	
	@Autowired
	UserBo ub;
	
	
	@Autowired
	UserBo1 ub1;
	
	
	@RequestMapping("/")
	public ModelAndView viewHomePage() {
		return new ModelAndView ("index") ;
	}
	@RequestMapping("/addtraininfo")
	public ModelAndView viewInfoPage() {
		return new ModelAndView ("addtraininfo") ;
	}
	@RequestMapping(value="insertinfo", method=RequestMethod.POST)
	public ModelAndView m1(HttpServletRequest request) {
		
		
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext();
		ac.scan("com.ltts.projecttrain");
		ac.refresh();
		
		int id=Integer.parseInt(request.getParameter("uid"));
		String name=request.getParameter("uname");
		String trainnames=request.getParameter("trainnames");
		String timings=request.getParameter("timings");
		String paymenttype=request.getParameter("paymenttype");
		
	//	Train t=ac.getBean(Train.class);
		Train t=new Train(id,name,trainnames,timings,paymenttype);
		
	//	t.setId(id);
	//	t.setName(name);
	//	t.setTrainnames(trainnames);
	//	t.setTimings(timings);
	//	t.setPaymenttype(paymenttype);
	
		
		
		
		System.out.println(t);
	//	System.out.println(name+" $$ "+id+" $$ "+trainnames+" $$ "+timings+" $$ "+paymenttype);
		
		
		td.save(t);
		return new ModelAndView ("success") ;
	}
	

	
	
	
	//Registration 
	
	@RequestMapping("/registration")
	public ModelAndView registerpage() {
	
	
	return new ModelAndView("registration");
	}

@RequestMapping(value="insertuser", method=RequestMethod.POST)
public ModelAndView insert(HttpServletRequest request) {
	
	

	String email=request.getParameter("email");
	String uname=request.getParameter("uname");
	
	
	
	String mobile=request.getParameter("mobile");
	String loca=request.getParameter("loca");
	LocalDate dob=LocalDate.parse(request.getParameter("dob"));
	String password=request.getParameter("password");
	
	
	
	User u1=new User(email,uname,mobile,loca,dob,password);
	boolean b=ub1.insertuser(u1);
	System.out.println(u1);
	if(b==false) {
		return new ModelAndView("success");
		
	}
	else {
		return new ModelAndView("error");
	}

}

@RequestMapping("/login")
public ModelAndView log() {
	return new ModelAndView ("login") ;
}

@RequestMapping(value="checkuser")
public ModelAndView cu(HttpServletRequest request, Model model) {
	ModelAndView mv=null;

	String email=request.getParameter("email");
	
	String mobile=request.getParameter("mobile");
	
	
	
	User u=ub1.checkUserByEmail(email);
	System.out.println("user"+u);
	if(u.equals(null)) {
		model.addAttribute("msg","Your username is wrong");
		mv=new ModelAndView("login");
	}
	else if(u.getEmail().equals(email)){
		if(mobile.equals(u.getMobile())) {
			model.addAttribute("email",u.getUname());
		mv=new ModelAndView("Welcome");
	}
		else {
			model.addAttribute("msg","Your password is wrong");
			mv=new ModelAndView("login");
		}
	}
	else {
		model.addAttribute("msg","Your email is wrong");
	mv=new ModelAndView("login");
	
	}
	return mv;
}

@RequestMapping("/bookticket")
public ModelAndView m1(Model model) {
	ModelAndView mv=new ModelAndView("bookticket");
	List<Train> li=td.findAll();
	model.addAttribute("list",li);
	System.out.println("Executed");
	
	return mv;
}



@RequestMapping("/viewtrain")
public ModelAndView viewtrains(Model model) {
	ModelAndView  mv1= new ModelAndView ("viewtrain");
	List<Train> li=td.findAll();
	model.addAttribute("list",li);
	return mv1;
	
	
}
/*
@RequestMapping("/viewtrain")
public List<Train> getTrain(){
	return td.findAll();
}

*/
}















/*	
	@RequestMapping(value="insertuser", method=RequestMethod.POST)
	public ModelAndView m2(HttpServletRequest request) {
		
		
		
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext();
		ac.scan("com.ltts.projecttrain");
		ac.refresh();
		
		String email=request.getParameter("email");
		String uname=request.getParameter("uname");
		
		
		
		String mobile=request.getParameter("mobile");
		String loca=request.getParameter("loca");
		LocalDate dob=LocalDate.parse(request.getParameter("dob"));
		String password=request.getParameter("password");
		
		User u=new User(email,uname,mobile,loca,dob,password);
	//	System.out.println(u);
	//	ub.insertuser(u);
	//	User u1=ac.getBean(User.class);
	//	u1=setUname(uname);
	//	u1.setEmail(email);
		
	//	u1.setMobile(mobile);
	//	u1.setLocation(loca);
	//	u1.setDob(dob);
	//	u1.setPassword(password);
		
		ub.save(u);
		
		System.out.println(u);
		
		
		return new ModelAndView("Success");
		
	}

	
}


@RequestMapping(value="insertuser", method=RequestMethod.POST)
public ModelAndView m2(HttpServletRequest request) {
	
	
	
	String email=request.getParameter("email");
	String uname=request.getParameter("uname");
	
	
	
	String mobile=request.getParameter("mobile");
	String loca=request.getParameter("loca");
	LocalDate dob=LocalDate.parse(request.getParameter("dob"));
	String password=request.getParameter("password");
	









	/*
	
//	@RequestMapping(value="insertuser", method=RequestMethod.POST)
//	public ModelAndView m2(HttpServletRequest request) {
		
		
		
		
		
//	public ModelAndView m2(@ModelAttribute User u,Model model, HttpServletRequest request) {
	//	public ModelAndView m2(User user) {

		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext();
		ac.scan("com.ltts.projecttrain");
		ac.refresh();
		String uname=request.getParameter("uname");
		String email=request.getParameter("email");
		
		
		String mobile=request.getParameter("mobile");
		String loca=request.getParameter("loca");
		LocalDate dob=LocalDate.parse(request.getParameter("dob"));
		String password=request.getParameter("password");
		
	//	User u=new User(email,uname,mobile,loca,dob,password);
//		ub.save(user);
	//	ub.save(user);
	//	System.out.println(u);
		
		
		
		
		
		
		
		
/*
		AnnotationConfigApplicationContext ac=new AnnotationConfigApplicationContext();
		ac.scan("com.ltts.projecttrain");
		ac.refresh();
		
		
		
		String name=request.getParameter("uname");
		String email=request.getParameter("email");
		String mobile=request.getParameter("mobile");
		String loca=request.getParameter("loca");
		LocalDate dob=LocalDate.parse(request.getParameter("dob"));
		String password=request.getParameter("password");
		
		

		*/
		/*
		
		User u1=ac.getBean(User.class);
			
	//	User u1=new User(email,name,mobile,loca,dob,password,"USER");
		u1.setUname(uname);
			u1.setEmail(email);
			
			u1.setMobile(mobile);
			u1.setLocation(loca);
			u1.setDob(dob);
			u1.setPassword(password);
			
			User.insertuser(u1);
			
			System.out.println(u1);
		*/
	/*
			@PostMapping("/exam_register")
			public ModelAndView examRegister(User u) {
				
				ub.save(u);
				
				return new ModelAndView("Success");
			
		
		
	}
	*/
	

