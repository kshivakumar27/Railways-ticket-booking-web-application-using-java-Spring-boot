package com.ltts.projecttrain.bo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ltts.projecttrain.model.Train;


@Repository
public interface Trainbo extends JpaRepository<Train,Integer>{

}
