package com.ltts.projecttrain.bo;

import java.io.Serializable;

import javax.persistence.EntityTransaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ltts.projecttrain.model.User;


@Repository
public interface UserBo extends JpaRepository<User,Long> {

	 //void save(UserBo ub);

	// void insertuser(User u1);


}

//*/


/*
@Repository
public interface UserBo extends JpaRepository<User,String> {
	@Query("SELECT u FROM User u WHERE u.email = ?1")
	public User findByEmail(String email);
	//void insertuser(User u);
	


}
*/
/*
@Repository
public interface UserBo {
	
	@Autowired
	SessionFactory sf;
	
	
	
	public default  boolean insertuser(User u) {
		System.out.println("Inside user bo beggining");
		Session s=sf.openSession();
		s.beginTransaction();
		
		//((EntityTransaction) s).commit();
		s.save(u);
		s.getTransaction().commit();
		s.close();
		System.out.println("Inside user bo Ending");
		return false;
	}



//	public void save(User u);

}

*/
