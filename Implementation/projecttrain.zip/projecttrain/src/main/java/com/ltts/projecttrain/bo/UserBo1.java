package com.ltts.projecttrain.bo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ltts.projecttrain.model.User;




@Repository
public class UserBo1 {

	@Autowired
	SessionFactory sf;
	
	public boolean insertuser(User u) {
		System.out.println("Insise User-Beg");
		Session s=sf.openSession();
		s.beginTransaction();
		s.save(u);
		s.getTransaction().commit();
		s.close();
		System.out.println("Inside User Bo-End");
	  return false;
	}
	
	public User checkUserByEmail(String email) {
		User u=new User();
	
	Session s=sf.openSession();
	s.beginTransaction();
	User u1=(User) s.load(User.class,email);
	
	s.getTransaction().commit();
	return u1;
	
}

	public User checkUserByEmail1(String Email) {
		// TODO Auto-generated method stub
		return null;
	}


	
}
