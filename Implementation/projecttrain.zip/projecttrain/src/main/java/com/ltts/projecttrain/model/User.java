package com.ltts.projecttrain.model;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import com.ltts.projecttrain.bo.UserBo;

@Component
@Entity
public class User {

	
	
	private String uname;
	@Id
	private String email;
	
	private String mobile;
	private String location;
	private LocalDate dob;
	
	private String password;
	//private String role;
	//private byte image[];

	
	
	
	
	public User() {
		super();
	}

	public User(String email, String uname, String mobile, String location, LocalDate dob, String password) {
		super();
		this.uname = uname;
		this.email = email;
		
		this.mobile = mobile;
		this.location = location;
		this.dob = dob;
		this.password = password;
	}
	
	
	
	
	
	public String getEmail() {
		return email;
	}

	

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "User [ uname=" + uname + ",email=" + email + ", mobile=" + mobile + ", location=" + location + ", dob="
				+ dob + ", password=" + password + "]";
	}



	
	
	
	
	
	
}
